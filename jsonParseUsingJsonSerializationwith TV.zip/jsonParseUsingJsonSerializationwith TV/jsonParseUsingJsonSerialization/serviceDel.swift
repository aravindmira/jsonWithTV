//
//  File.swift
//  ServiceDel
//
//  Created by Aravind on 12/11/19.
//  Copyright © 2019 Aravind. All rights reserved.
//

import Foundation
protocol ServiceDelegate {
    func reloadData(Response :NSArray)
}
