//
//  HttpServiceClass.swift
//  ServiceDel
//
//  Created by Aravind on 12/3/19.
//  Copyright © 2019 Aravind. All rights reserved.
//

import UIKit
let configUrl = "https://next.json-generator.com/"
class HttpServiceClass: NSObject {
    
    var delegateVar:ServiceDelegate?
    func postWebService()  {
       
        let request = NSMutableURLRequest(url: NSURL(string: "\(configUrl)api/json/get/E1vU-KbAD")! as URL)
        
        //header file if they needed
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        //Normal post with jsonserilization
//        let json = NSDictionary()
//        json.setValue("2601", forKey: "user_id")
//        json.setValue("864de06773751fc717b883fa507c14a4", forKey: "user_auth_token")
//        json.setValue("month", forKey: "filter_type")
//
//        let jsonData = try? JSONSerialization.data(withJSONObject: json)
//         request.httpMethod = "POST"
//        request.httpBody = jsonData
        //
        
        //Normal get method
         request.httpMethod = "GET"
        //
        //Normal post with Sring encoding
//        request.httpMethod = "POST"
//           let postString = "user_id=2601&user_auth_token=864de06773751fc717b883fa507c14a4&filter_type=month"
//
//        request.httpBody = postString.data(using:String.Encoding.utf8)
        //
       
        let task = URLSession.shared.dataTask(with: request as URLRequest){data, response, error in
               guard error == nil && data != nil else{
                   print("error")
                   return
               }

            var json = NSDictionary()
            do {
               // json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers)  as! NSArray
                let jsonData:NSArray = (try JSONSerialization.jsonObject(with: data!, options:JSONSerialization.ReadingOptions.mutableContainers) as? NSArray)!


                DispatchQueue.main.async {
                    self.delegateVar?.reloadData(Response: jsonData)
                }
                
            } catch {
                print("Something went wrong")
            }
        
           }
           task.resume()
           
       }
}
