//
//  TVCell.swift
//  jsonParseUsingJsonSerialization
//
//  Created by Aravind on 12/24/19.
//  Copyright © 2019 8KMILES. All rights reserved.
//

import UIKit

class TVCell: UITableViewCell {

    @IBOutlet weak var CellLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
