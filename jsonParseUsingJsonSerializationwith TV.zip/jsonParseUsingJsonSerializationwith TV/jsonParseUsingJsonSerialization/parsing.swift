//
//  parsing.swift
//  jsonParseUsingJsonSerialization
//
//  Created by Aravind on 12/24/19.
//  Copyright © 2019 8KMILES. All rights reserved.
//

import UIKit

class parsing: NSObject {

    func getName(Response: NSArray) -> [String] {
        var nameArr = [String]()
        for i in 0...Response.count-1{
           let levelDict:AnyObject = Response[i] as AnyObject
          // print(levelDict["friends"] as AnyObject? as! NSArray)
           let friendsArr = levelDict["friends"] as AnyObject? as! NSArray
            for j in 0...friendsArr.count-1{
                let levelDict:AnyObject = friendsArr[j] as AnyObject
                 print(levelDict["name"] as AnyObject? as! NSString)
                nameArr.append(levelDict["name"]as AnyObject?as!String)
            }

        }
        return nameArr
        
    }
}
