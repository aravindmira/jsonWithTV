//
//  ViewController.swift
//  jsonParseUsingJsonSerialization
//
//  Created by 8KMILES on 17/12/19.
//  Copyright © 2019 8KMILES. All rights reserved.
//

import UIKit

class ViewController: UIViewController,ServiceDelegate,UITableViewDelegate,UITableViewDataSource {
     var nameArr = [String]()
    
    @IBOutlet weak var TableView: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.nameArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVCell", for: indexPath)as! TVCell
        cell.CellLbl?.text = nameArr[indexPath.row]

//            let headline = headlines[indexPath.row]
//            cell.headlineTitleLabel?.text = headline.title
//        cell.headlineTextLabel?.text = headline.text
//        cell.headlineImageView?.image = UIImage(named: headline.image)
         return cell
    }
    
   
    
    
    
    
    func reloadData(Response: NSArray) {
         print("response on vc \(Response)")
        // To implement 2 for ; array inside array
//        for i in 0...Response.count-1{
//           let levelDict:AnyObject = Response[i] as AnyObject
//          // print(levelDict["friends"] as AnyObject? as! NSArray)
//           let friendsArr = levelDict["friends"] as AnyObject? as! NSArray
//            for j in 0...friendsArr.count-1{
//                let levelDict:AnyObject = friendsArr[j] as AnyObject
//                 print(levelDict["name"] as AnyObject? as! NSString)
//                nameArr.append(levelDict["name"]as AnyObject?as!String)
//            }
//
//        }
        let parobj = parsing()
        nameArr =  parobj.getName(Response: Response)
        
        
        //To implement get dictionary value.
        for i in 0...Response.count-1{
           let levelDict:AnyObject = Response[i] as AnyObject
            //print(levelDict["name"] as AnyObject? as! NSDictionary)
            let nameDic = levelDict["name"] as AnyObject? as! NSDictionary
            print(nameDic.value(forKey: "first")as!NSString)
            
        }
       print(nameArr)
        self.TableView.reloadData()
        
    }
    
 var HttpSerClsVar=HttpServiceClass()
    override func viewDidLoad() {
        super.viewDidLoad()
        HttpSerClsVar.postWebService()
        HttpSerClsVar.delegateVar=self;
      //tvcell  let tvcell = TVCell.self;
    
       
    }


}

